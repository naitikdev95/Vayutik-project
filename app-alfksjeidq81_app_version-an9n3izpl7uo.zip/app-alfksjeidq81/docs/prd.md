# Requirements Document

## 1. Application Overview

- **Application Name:** AppVault
- **Description:** AppVault is a premium, visually stunning web platform for discovering, reviewing, and saving digital products — including apps, software, websites, SaaS tools, and web apps. The platform features a high-end 3D landing experience, user authentication, product listings with ratings and reviews, and a personalized user dashboard. The UI/UX follows a professional, modern design system with refined typography, consistent spacing, polished micro-interactions, and a dedicated bottom navigation bar for mobile devices.

---

## 2. Users & Use Cases

### 2.1 Target Users
- General users looking to discover and evaluate digital products
- Registered users who want to rate, review, and save products
- Platform administrators managing product listings

### 2.2 Core Use Cases
- Browse and search digital product listings
- View detailed product pages with images, descriptions, and reviews
- Register/login to submit ratings and reviews
- Save (「install」) products to a personal dashboard
- Manage saved products and personal profile from the dashboard

---

## 3. Page Structure & Core Features

### 3.1 Page Overview

```
AppVault
├── Landing Page (Public)
├── Product Listing Page (Public)
├── Product Detail Page (Public)
├── Auth Pages
│   ├── Register Page
│   └── Login Page
├── User Dashboard (Authenticated)
│   ├── Saved Products
│   └── Profile Settings
└── (Admin) Product Management (Authenticated — Admin Role)
```

### 3.2 Design System & UI/UX Standards

**Color & Visual Language:**
- Primary palette: deep neutral backgrounds (e.g., near-black #0A0A0F or #0F0F1A) with vibrant accent colors (e.g., electric indigo, violet, or cyan gradient) for CTAs, highlights, and interactive states
- Surface layers use subtle glassmorphism cards: semi-transparent backgrounds with backdrop blur, soft border (1px rgba white/10), and gentle box shadow
- Text hierarchy: large, bold display fonts for headings (e.g., 48–72px on desktop), medium-weight subheadings, and regular-weight body text with high contrast ratios (WCAG AA minimum)

**Typography:**
- Display/heading font: modern geometric sans-serif (e.g., Inter, Sora, or Geist) at bold/extrabold weight
- Body font: same family at regular/medium weight, line-height 1.6–1.75 for readability
- Consistent type scale across all pages: display, h1–h4, body-lg, body, caption

**Spacing & Layout:**
- 8px base grid system; all spacing values are multiples of 8
- Generous whitespace between sections (80–120px vertical padding on desktop, 48–64px on mobile)
- Max content width: 1280px centered with responsive side padding

**Interactive States & Micro-interactions:**
- All interactive elements (buttons, cards, links, tabs) have clearly defined hover, focus, active, and disabled states
- Buttons: smooth scale transform (1.02–1.04) and background/shadow transition on hover (150–200ms ease)
- Cards: subtle lift effect on hover — translateY(-4px) with enhanced shadow
- Star rating selector: animated fill transition per star on hover and selection
- Form inputs: smooth border-color and glow transition on focus
- Page transitions: fade-in or slide-up entrance animations for main content blocks (staggered where appropriate)
- Loading states: skeleton screens for product cards and detail pages instead of spinners where possible

**Iconography:**
- Consistent icon set throughout (e.g., Lucide or Phosphor icons), uniform stroke weight, sized to match text context

**Responsive Breakpoints:**
- Mobile: < 768px
- Tablet: 768px – 1023px
- Desktop: ≥ 1024px

---

### 3.3 Landing Page

- **3D Hero Section:** Visually stunning 3D animated hero built with Three.js or @react-three/fiber, fully responsive across all screen sizes and devices
- Hero includes a headline, subheadline, and a prominent CTA button directing users to the product listing page
- Hero text uses large display typography with a subtle gradient or glow effect on the headline
- CTA button is large, high-contrast, with animated gradient border or fill on hover
- Featured products section showcasing top-rated or recently added products, displayed as polished glassmorphism cards in a horizontal scroll or grid layout
- Brief platform value proposition section with icon + heading + description layout in a clean 3-column grid (stacks to 1 column on mobile)
- Navigation bar: fixed/sticky top bar with frosted glass background (backdrop-filter blur), platform logo on the left, nav links centered or right-aligned, and a prominent Login/Register CTA button; collapses to hamburger menu on tablet and is replaced by bottom navigation bar on mobile
- Footer: dark background, platform name and tagline, organized link columns, social icons, and copyright line

### 3.4 Product Listing Page

- Page header with title and result count
- Search bar: full-width on mobile, prominent placement, with clear icon and smooth focus state
- Category filter: pill/chip style tabs with active state highlight; horizontally scrollable on mobile
- Grid layout: 3 columns on desktop, 2 on tablet, 1 on mobile
- Each product card (glassmorphism style):
  - Product thumbnail image with aspect-ratio lock and object-fit cover
  - Category badge (color-coded pill)
  - Product name in bold
  - Short description (2-line clamp with ellipsis)
  - Star rating display with numeric average and review count
  - Subtle hover lift animation
- Pagination or infinite scroll for large product sets
- Empty state: illustrated or icon-based empty state with message 「No products found matching your search」

### 3.5 Product Detail Page

- Full-width hero area with product name, category badge, and average star rating prominently displayed
- Image gallery: main image with thumbnail strip below; smooth transition between images on selection
- Product description in well-spaced, readable body text
- 「Save / Install」 button: large, accent-colored, with icon; transitions to 「Saved ✓」 state with color change after action
- If unauthenticated: button replaced with 「Log in to Save」 prompt styled as a secondary CTA
- Reviews section:
  - Summary bar: large average rating number, star display, total review count, and rating distribution bar chart
  - Review cards: reviewer avatar (initials-based fallback), name, star rating, date, and comment text
  - Review submission form (authenticated users only): star rating selector with animated fill + comment textarea + submit button
  - If user has already reviewed: display their existing review with an inline edit option
  - Users may only submit one review per product
- If unauthenticated, show inline prompt: 「Please log in to submit a review」

### 3.6 Register Page

- Centered card layout on a subtle gradient or blurred background
- Fields: Full Name, Email, Password, Confirm Password
- Each field has a floating label or clearly styled label above, with icon prefix inside input
- Real-time inline validation with smooth error message appearance
- Primary CTA button: full-width, high-contrast, with loading state on submit
- Client-side and server-side validation
- On success: redirect to Dashboard
- Link to Login page styled as a secondary text link

### 3.7 Login Page

- Same centered card layout as Register page for visual consistency
- Fields: Email, Password (with show/hide toggle)
- JWT-based authentication
- On success: redirect to Dashboard
- Link to Register page
- 「Forgot Password」 link (out of scope for this release — see Section 7)

### 3.8 User Dashboard (Authenticated)

**Layout:**
- Sidebar navigation on desktop (collapsible); tab bar on tablet; replaced by bottom navigation bar on mobile
- Clean page header with user avatar (initials-based), display name, and greeting

**Saved Products Tab:**
- Grid/list toggle option
- Each item: product thumbnail, name, category badge, average rating, and a remove button (icon button with confirmation tooltip or inline undo)
- Empty state: illustrated empty state with message 「You haven't saved any products yet. Explore the catalog!」 and a CTA to the listing page
- Clicking a product navigates to its Product Detail Page

**Profile Settings Tab:**
- Section cards for each settings group
- View and update: Full Name, Email
- Change password form: Current Password, New Password, Confirm New Password — each with show/hide toggle
- Save changes button with loading and success states

### 3.9 Admin — Product Management (Authenticated, Admin Role)

- Add new product: Name, Category, Description, Images (upload with drag-and-drop zone and preview), External URL (optional)
- Edit existing product details via inline edit or modal
- Delete a product with confirmation dialog
- View all submitted reviews per product with option to delete inappropriate reviews
- Admin panel uses the same design system with a distinct admin badge/indicator in the navigation

---

## 4. Mobile Bottom Navigation Bar

### 4.1 Behavior & Visibility
- The bottom navigation bar is displayed exclusively on mobile devices (viewport width < 768px)
- It replaces the top navigation bar as the primary navigation mechanism on mobile
- It is fixed to the bottom of the viewport, always visible during scrolling
- It does not appear on tablet or desktop breakpoints

### 4.2 Structure & Items
- The bottom nav contains 4–5 icon + label items depending on authentication state:
  - **Unauthenticated state:** Home, Explore, Login, Register
  - **Authenticated (regular user):** Home, Explore, Saved, Dashboard
  - **Authenticated (admin):** Home, Explore, Saved, Dashboard, Admin
- Each item consists of a vector icon above a short text label (max 10 characters)
- The active item is highlighted with the accent color; inactive items use a muted foreground color

### 4.3 Visual Design
- Background: frosted glass effect (semi-transparent dark background with backdrop-filter blur) or solid dark surface matching the app's color palette
- Top border: 1px subtle separator line
- Safe area padding: accounts for iOS home indicator (env(safe-area-inset-bottom))
- Height: approximately 56–64px plus safe area inset
- Smooth active state transition (color + subtle scale on tap)

### 4.4 Interaction
- Tapping an item navigates to the corresponding page and updates the active state immediately
- No hamburger menu or slide-out drawer is used on mobile; all primary navigation is handled by the bottom bar

---

## 5. Business Rules & Logic

### 5.1 Authentication & Authorization
- All write actions (save product, submit review, edit profile) require a valid JWT session
- JWT tokens are issued on login/register and must be included in all authenticated API requests
- Admin-only routes are protected by role-based access control; regular users cannot access admin endpoints
- Tokens expire after a defined period; expired tokens redirect the user to the login page

### 5.2 Product Save (「Install」) Logic
- A user may save any product once; duplicate saves are silently ignored or show an 「Already Saved」 state
- Removing a saved product is immediate and reflected in the dashboard without page reload

### 5.3 Review & Rating Logic
- Each authenticated user may submit exactly one review per product
- If a user has already reviewed a product, the submission form is replaced with their existing review and an edit option
- Average rating is recalculated on every new review submission or edit
- Star rating must be an integer between 1 and 5 (inclusive)
- Comment text is required; minimum 10 characters

### 5.4 Data Relationships
- Users → many saved products (many-to-many)
- Users → many reviews (one per product)
- Products → many reviews
- Products → one category

---

## 6. Exceptions & Edge Cases

| Scenario | Handling |
|---|---|
| Unauthenticated user clicks 「Save / Install」 | Redirect to Login page with return URL |
| Unauthenticated user attempts to submit a review | Show inline prompt: 「Please log in to submit a review」 |
| User submits a duplicate review | Show error: 「You have already reviewed this product」 |
| Product has no reviews yet | Display 「No reviews yet. Be the first to review!」 |
| Product has no images | Display a default placeholder image |
| Search returns no results | Display 「No products found matching your search」 |
| Invalid login credentials | Show error: 「Invalid email or password」 |
| Registration with existing email | Show error: 「An account with this email already exists」 |
| Password mismatch on register/change | Show inline validation error |
| Admin deletes a product with saved references | Remove product from all users' saved lists |
| Empty dashboard saved list | Display 「You haven't saved any products yet. Explore the catalog!」 |
| 3D hero fails to load on low-end device | Gracefully fall back to a static gradient hero with no layout breakage |
| Bottom nav active state on deep nested route | Highlight the parent nav item corresponding to the current route |

---

## 7. Acceptance Criteria

- The landing page renders a fully interactive 3D hero section on desktop, tablet, and mobile without layout breakage; a static gradient fallback is shown if 3D fails to load
- The design system (color palette, typography scale, spacing, glassmorphism cards, micro-interactions) is consistently applied across all pages
- All interactive elements (buttons, cards, inputs, tabs, stars) have clearly defined and visually distinct hover, focus, active, and disabled states
- The bottom navigation bar is visible and functional on all viewports below 768px width, and is hidden on tablet and desktop
- Bottom navigation correctly reflects the active route and updates authentication-aware items based on login state
- Unauthenticated users can browse all product listings and detail pages
- Authenticated users can save products and see them reflected immediately in the dashboard
- Authenticated users can submit, view, and edit their own review on any product
- Average star rating updates correctly after each review submission or edit
- JWT authentication is enforced on all protected routes; expired/invalid tokens are rejected
- Admin users can create, edit, and delete products and reviews via the admin panel
- All forms include client-side validation with clear, inline error messages and smooth appearance transitions
- The application is fully responsive and visually consistent across Chrome, Firefox, Safari, and Edge on desktop and mobile
- Passwords are stored as secure hashes (e.g., bcrypt); plain-text passwords are never stored or logged
- Skeleton loading screens are displayed for product cards and detail pages during data fetch

---

## 8. Out of Scope (This Release)

- Forgot Password / Password Reset via email
- Social login (Google, GitHub, etc.)
- Product submission by regular users (user-generated listings)
- Notifications or email alerts
- Payment or monetization features
- Advanced analytics or admin reporting dashboard
- Multi-language / internationalization support
- Dark mode toggle
- Product versioning or changelog tracking