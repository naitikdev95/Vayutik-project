import { Link, useLocation } from 'react-router-dom';
import { Home, Package, LayoutDashboard, User, LogIn } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

export function BottomNav() {
  const location = useLocation();
  const { user } = useAuth();

  const navItems = user
    ? [
        { to: '/', icon: Home, label: 'Home' },
        { to: '/products', icon: Package, label: 'Products' },
        { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
        { to: '/dashboard', icon: User, label: 'Profile' }
      ]
    : [
        { to: '/', icon: Home, label: 'Home' },
        { to: '/products', icon: Package, label: 'Products' },
        { to: '/login', icon: LogIn, label: 'Sign In' },
        { to: '/register', icon: User, label: 'Sign Up' }
      ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 md:hidden">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.to;
          const Icon = item.icon;

          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                'flex flex-col items-center justify-center gap-1 rounded-lg px-4 py-2 transition-colors',
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className={cn('h-5 w-5', isActive && 'fill-primary/20')} />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
