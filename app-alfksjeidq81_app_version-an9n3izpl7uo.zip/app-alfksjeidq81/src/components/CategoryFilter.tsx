import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { ProductCategory } from '@/types/types';

interface CategoryFilterProps {
  selectedCategory: ProductCategory | 'All';
  onCategoryChange: (category: ProductCategory | 'All') => void;
}

const categories: Array<ProductCategory | 'All'> = ['All', 'App', 'Software', 'Website', 'SaaS', 'Web App'];

export function CategoryFilter({ selectedCategory, onCategoryChange }: CategoryFilterProps) {
  return (
    <Tabs value={selectedCategory} onValueChange={(value) => onCategoryChange(value as ProductCategory | 'All')}>
      <TabsList className="w-full justify-start overflow-x-auto">
        {categories.map((category) => (
          <TabsTrigger key={category} value={category} className="whitespace-nowrap">
            {category}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
}
