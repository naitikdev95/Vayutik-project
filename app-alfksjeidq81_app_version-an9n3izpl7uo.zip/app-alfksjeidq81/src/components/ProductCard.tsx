import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StarRating } from './StarRating';
import type { Product } from '@/types/types';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const thumbnailImage = product.images?.[0] || '/placeholder-product.jpg';

  return (
    <Link to={`/products/${product.id}`}>
      <Card className="group h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:border-primary/50 hover:-translate-y-1">
        <CardHeader className="p-0">
          <div className="relative aspect-video w-full overflow-hidden bg-gradient-to-br from-muted to-muted/50">
            <img
              src={thumbnailImage}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
          </div>
        </CardHeader>
        <CardContent className="p-5">
          <div className="mb-3 flex items-start justify-between gap-2">
            <h3 className="line-clamp-1 text-lg font-bold transition-colors group-hover:text-primary">{product.name}</h3>
            <Badge variant="secondary" className="shrink-0 shadow-sm">
              {product.category}
            </Badge>
          </div>
          <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">
            {product.short_description}
          </p>
        </CardContent>
        <CardFooter className="p-5 pt-0">
          <div className="flex items-center justify-between w-full">
            <StarRating rating={product.average_rating || 0} size={16} />
            <span className="text-xs font-medium text-muted-foreground">
              {product.review_count || 0} {product.review_count === 1 ? 'review' : 'reviews'}
            </span>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
