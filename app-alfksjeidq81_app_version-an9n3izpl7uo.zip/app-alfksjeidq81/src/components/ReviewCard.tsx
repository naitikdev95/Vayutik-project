import { Card, CardContent } from '@/components/ui/card';
import { StarRating } from './StarRating';
import type { Review } from '@/types/types';
import { formatDistanceToNow } from 'date-fns';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface ReviewCardProps {
  review: Review;
}

export function ReviewCard({ review }: ReviewCardProps) {
  const userName = review.user?.full_name || 'Anonymous User';
  const initials = userName
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="transition-all hover:shadow-md">
      <CardContent className="p-6">
        <div className="mb-4 flex items-start gap-4">
          <Avatar className="h-10 w-10 border-2 border-primary/10">
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="mb-2 flex items-start justify-between gap-4">
              <div>
                <p className="font-semibold">{userName}</p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(review.created_at), { addSuffix: true })}
                </p>
              </div>
              <StarRating rating={review.rating} size={16} />
            </div>
            <p className="text-sm leading-relaxed text-foreground/90">{review.comment}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
