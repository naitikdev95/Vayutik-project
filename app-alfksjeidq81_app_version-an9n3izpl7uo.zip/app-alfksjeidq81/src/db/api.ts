import { supabase } from './supabase';
import type { Product, Review, SavedProduct, Profile, ProductCategory } from '@/types/types';

// Products API
export async function getAllProducts(
  category?: ProductCategory,
  searchQuery?: string,
  limit = 12,
  offset = 0
): Promise<Product[]> {
  let query = supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (category) {
    query = query.eq('category', category);
  }

  if (searchQuery) {
    query = query.ilike('name', `%${searchQuery}%`);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getProductById(id: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Error fetching product:', error);
    return null;
  }

  return data;
}

export async function createProduct(product: Omit<Product, 'id' | 'average_rating' | 'review_count' | 'created_at' | 'updated_at'>): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .insert(product)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating product:', error);
    return null;
  }

  return data;
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating product:', error);
    return null;
  }

  return data;
}

export async function deleteProduct(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting product:', error);
    return false;
  }

  return true;
}

export async function getProductCount(category?: ProductCategory, searchQuery?: string): Promise<number> {
  let query = supabase
    .from('products')
    .select('*', { count: 'exact', head: true });

  if (category) {
    query = query.eq('category', category);
  }

  if (searchQuery) {
    query = query.ilike('name', `%${searchQuery}%`);
  }

  const { count, error } = await query;

  if (error) {
    console.error('Error counting products:', error);
    return 0;
  }

  return count || 0;
}

// Reviews API
export async function getReviewsByProductId(productId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      user:profiles!reviews_user_id_fkey(full_name)
    `)
    .eq('product_id', productId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching reviews:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getUserReviewForProduct(userId: string, productId: string): Promise<Review | null> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching user review:', error);
    return null;
  }

  return data;
}

export async function createReview(review: { product_id: string; user_id: string; rating: number; comment: string }): Promise<Review | null> {
  const { data, error } = await supabase
    .from('reviews')
    .insert(review)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating review:', error);
    return null;
  }

  return data;
}

export async function updateReview(id: string, updates: { rating: number; comment: string }): Promise<Review | null> {
  const { data, error } = await supabase
    .from('reviews')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating review:', error);
    return null;
  }

  return data;
}

export async function deleteReview(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('reviews')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting review:', error);
    return false;
  }

  return true;
}

export async function getAllReviews(): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      user:profiles!reviews_user_id_fkey(full_name)
    `)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching all reviews:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

// Saved Products API
export async function getSavedProducts(userId: string): Promise<SavedProduct[]> {
  const { data, error } = await supabase
    .from('saved_products')
    .select(`
      *,
      product:products(*)
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching saved products:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function isProductSaved(userId: string, productId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('saved_products')
    .select('id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (error) {
    console.error('Error checking saved product:', error);
    return false;
  }

  return !!data;
}

export async function saveProduct(userId: string, productId: string): Promise<boolean> {
  const { error } = await supabase
    .from('saved_products')
    .insert({ user_id: userId, product_id: productId });

  if (error) {
    console.error('Error saving product:', error);
    return false;
  }

  return true;
}

export async function unsaveProduct(userId: string, productId: string): Promise<boolean> {
  const { error } = await supabase
    .from('saved_products')
    .delete()
    .eq('user_id', userId)
    .eq('product_id', productId);

  if (error) {
    console.error('Error unsaving product:', error);
    return false;
  }

  return true;
}

// Profile API
export async function updateProfile(id: string, updates: { full_name?: string; email?: string }): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating profile:', error);
    return null;
  }

  return data;
}

export async function getAllProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching profiles:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function updateUserRole(userId: string, role: 'user' | 'admin'): Promise<boolean> {
  const { error } = await supabase
    .from('profiles')
    .update({ role })
    .eq('id', userId);

  if (error) {
    console.error('Error updating user role:', error);
    return false;
  }

  return true;
}

// Image upload helper
export async function uploadProductImage(file: File): Promise<string | null> {
  const fileExt = file.name.split('.').pop();
  const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
  const filePath = `products/${fileName}`;

  const { error } = await supabase.storage
    .from('app-alfksjeidq81_product_images')
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false
    });

  if (error) {
    console.error('Error uploading image:', error);
    return null;
  }

  const { data } = supabase.storage
    .from('app-alfksjeidq81_product_images')
    .getPublicUrl(filePath);

  return data.publicUrl;
}
