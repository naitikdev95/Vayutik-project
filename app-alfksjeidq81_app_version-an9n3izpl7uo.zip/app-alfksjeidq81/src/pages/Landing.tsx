import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Hero3D } from '@/components/Hero3D';
import { ProductCard } from '@/components/ProductCard';
import { ArrowRight, Sparkles, Shield, Zap, TrendingUp } from 'lucide-react';
import { getAllProducts } from '@/db/api';
import type { Product } from '@/types/types';
import { Skeleton } from '@/components/ui/skeleton';

export default function Landing() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFeaturedProducts = async () => {
      const products = await getAllProducts(undefined, undefined, 6, 0);
      setFeaturedProducts(products);
      setLoading(false);
    };
    loadFeaturedProducts();
  }, []);

  return (
    <div className="flex flex-col">
      <section className="relative flex min-h-[600px] items-center overflow-hidden bg-gradient-to-br from-background via-accent/20 to-background md:min-h-[700px]">
        <div className="absolute inset-0 opacity-40">
          <Hero3D />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background" />
        <div className="container relative z-10 mx-auto px-4 py-20">
          <div className="mx-auto max-w-4xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border bg-background/50 px-4 py-2 text-sm font-medium backdrop-blur-sm">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span>Discover the Future of Digital Products</span>
            </div>
            <h1 className="mb-6 text-4xl font-bold leading-tight md:text-6xl lg:text-7xl">
              Discover the Best{' '}
              <span className="gradient-text">Digital Products</span>
            </h1>
            <p className="mb-10 text-lg text-muted-foreground md:text-xl lg:text-2xl">
              Explore, review, and save your favorite apps, software, and digital tools all in one place
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" asChild className="w-full sm:w-auto shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all">
                <Link to="/products">
                  Explore Products <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto border-2 hover:bg-accent">
                <Link to="/register">Get Started Free</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b bg-gradient-to-b from-muted/30 to-background py-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="group flex flex-col items-center text-center transition-transform hover:-translate-y-2">
              <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-lg transition-all group-hover:shadow-xl group-hover:shadow-primary/20">
                <Sparkles className="h-10 w-10 text-primary" />
              </div>
              <h3 className="mb-3 text-xl font-bold">Curated Collection</h3>
              <p className="text-muted-foreground leading-relaxed">
                Discover hand-picked digital products across multiple categories
              </p>
            </div>
            <div className="group flex flex-col items-center text-center transition-transform hover:-translate-y-2">
              <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-lg transition-all group-hover:shadow-xl group-hover:shadow-primary/20">
                <Shield className="h-10 w-10 text-primary" />
              </div>
              <h3 className="mb-3 text-xl font-bold">Trusted Reviews</h3>
              <p className="text-muted-foreground leading-relaxed">
                Read authentic reviews from real users to make informed decisions
              </p>
            </div>
            <div className="group flex flex-col items-center text-center transition-transform hover:-translate-y-2">
              <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-lg transition-all group-hover:shadow-xl group-hover:shadow-primary/20">
                <Zap className="h-10 w-10 text-primary" />
              </div>
              <h3 className="mb-3 text-xl font-bold">Save & Organize</h3>
              <p className="text-muted-foreground leading-relaxed">
                Build your personal collection of favorite digital products
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">Featured Products</h2>
            <p className="text-lg text-muted-foreground md:text-xl">
              Check out some of our top-rated digital products
            </p>
          </div>

          {loading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="aspect-video w-full bg-muted" />
                  <Skeleton className="h-6 w-3/4 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                </div>
              ))}
            </div>
          ) : featuredProducts.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="py-12 text-center">
              <p className="text-muted-foreground">No products available yet.</p>
            </div>
          )}

          <div className="mt-16 text-center">
            <Button size="lg" variant="outline" asChild className="border-2">
              <Link to="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
