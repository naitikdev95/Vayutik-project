import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { StarRating } from '@/components/StarRating';
import { ReviewCard } from '@/components/ReviewCard';
import { ReviewForm } from '@/components/ReviewForm';
import { useAuth } from '@/contexts/AuthContext';
import { getProductById, getReviewsByProductId, getUserReviewForProduct, saveProduct, unsaveProduct, isProductSaved } from '@/db/api';
import type { Product, Review } from '@/types/types';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { Download, ExternalLink, ArrowLeft, Check } from 'lucide-react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [userReview, setUserReview] = useState<Review | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [savingProduct, setSavingProduct] = useState(false);

  useEffect(() => {
    const loadProductData = async () => {
      if (!id) return;

      setLoading(true);
      const [productData, reviewsData] = await Promise.all([
        getProductById(id),
        getReviewsByProductId(id)
      ]);

      setProduct(productData);
      setReviews(reviewsData);

      if (user) {
        const [savedStatus, existingReview] = await Promise.all([
          isProductSaved(user.id, id),
          getUserReviewForProduct(user.id, id)
        ]);
        setIsSaved(savedStatus);
        setUserReview(existingReview);
      }

      setLoading(false);
    };

    loadProductData();
  }, [id, user]);

  const handleSaveToggle = async () => {
    if (!user || !id) {
      navigate('/login');
      return;
    }

    setSavingProduct(true);
    try {
      if (isSaved) {
        const success = await unsaveProduct(user.id, id);
        if (success) {
          setIsSaved(false);
          toast.success('Product removed from your collection');
        } else {
          toast.error('Failed to remove product');
        }
      } else {
        const success = await saveProduct(user.id, id);
        if (success) {
          setIsSaved(true);
          toast.success('Product saved to your collection');
        } else {
          toast.error('Failed to save product');
        }
      }
    } finally {
      setSavingProduct(false);
    }
  };

  const handleReviewSuccess = async () => {
    if (!id) return;
    const [reviewsData, productData] = await Promise.all([
      getReviewsByProductId(id),
      getProductById(id)
    ]);
    setReviews(reviewsData);
    setProduct(productData);
    if (user) {
      const existingReview = await getUserReviewForProduct(user.id, id);
      setUserReview(existingReview);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="mb-8 h-10 w-32 bg-muted" />
        <div className="grid gap-8 lg:grid-cols-2">
          <Skeleton className="aspect-video w-full bg-muted" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4 bg-muted" />
            <Skeleton className="h-6 w-1/4 bg-muted" />
            <Skeleton className="h-24 w-full bg-muted" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="mb-4 text-2xl font-bold">Product Not Found</h1>
        <Button asChild>
          <Link to="/products">Back to Products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="ghost" asChild className="mb-6 hover:bg-accent">
        <Link to="/products">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Products
        </Link>
      </Button>

      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          {product.images && product.images.length > 0 ? (
            <Carousel className="w-full">
              <CarouselContent>
                {product.images.map((image, index) => (
                  <CarouselItem key={index}>
                    <div className="aspect-video w-full overflow-hidden rounded-2xl border-2 bg-gradient-to-br from-muted to-muted/50 shadow-xl">
                      <img
                        src={image}
                        alt={`${product.name} - Image ${index + 1}`}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              {product.images.length > 1 && (
                <>
                  <CarouselPrevious className="left-4" />
                  <CarouselNext className="right-4" />
                </>
              )}
            </Carousel>
          ) : (
            <div className="aspect-video w-full rounded-2xl bg-gradient-to-br from-muted to-muted/50" />
          )}
        </div>

        <div className="space-y-6">
          <div>
            <div className="mb-3 flex items-start justify-between gap-4">
              <h1 className="text-3xl font-bold leading-tight md:text-4xl">{product.name}</h1>
              <Badge variant="secondary" className="shrink-0 text-sm shadow-sm">
                {product.category}
              </Badge>
            </div>
            <div className="flex items-center gap-4">
              <StarRating rating={product.average_rating || 0} />
              <span className="text-sm font-medium text-muted-foreground">
                {product.review_count || 0} {product.review_count === 1 ? 'review' : 'reviews'}
              </span>
            </div>
          </div>

          <p className="text-lg leading-relaxed text-muted-foreground">{product.short_description}</p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              size="lg"
              onClick={handleSaveToggle}
              disabled={savingProduct}
              className="flex-1 shadow-lg"
              variant={isSaved ? 'secondary' : 'default'}
            >
              {isSaved ? (
                <>
                  <Check className="mr-2 h-5 w-5" />
                  Saved to Collection
                </>
              ) : (
                <>
                  <Download className="mr-2 h-5 w-5" />
                  Save to Collection
                </>
              )}
            </Button>
            {product.external_url && (
              <Button size="lg" variant="outline" asChild className="border-2">
                <a href={product.external_url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-5 w-5" />
                  Visit Website
                </a>
              </Button>
            )}
          </div>

          <Separator />

          <div>
            <h2 className="mb-4 text-2xl font-bold">About</h2>
            <p className="leading-relaxed text-foreground/90">{product.description}</p>
          </div>
        </div>
      </div>

      <Separator className="my-16" />

      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <h2 className="mb-6 text-2xl font-bold">Reviews ({reviews.length})</h2>
          {reviews.length > 0 ? (
            <div className="space-y-4">
              {reviews.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>
          ) : (
            <Card className="border-2 border-dashed">
              <CardContent className="py-16 text-center">
                <p className="text-lg font-medium text-muted-foreground">
                  No reviews yet. Be the first to review!
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        <div>
          <h2 className="mb-6 text-2xl font-bold">
            {userReview ? 'Your Review' : 'Write a Review'}
          </h2>
          {user ? (
            <Card className="border-2 shadow-lg">
              <CardContent className="p-6">
                <ReviewForm
                  productId={product.id}
                  userId={user.id}
                  existingReview={userReview}
                  onSuccess={handleReviewSuccess}
                />
              </CardContent>
            </Card>
          ) : (
            <Card className="border-2 border-dashed">
              <CardContent className="py-16 text-center">
                <p className="mb-6 text-lg font-medium text-muted-foreground">
                  Please log in to submit a review
                </p>
                <Button asChild size="lg">
                  <Link to="/login">Sign In</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
