declare module '@react-three/fiber' {
  export * from '@react-three/fiber/dist/declarations/src/index';
}

declare module '@react-three/drei' {
  export * from '@react-three/drei/core';
}

declare namespace JSX {
  interface IntrinsicElements {
    ambientLight: any;
    directionalLight: any;
    pointLight: any;
    mesh: any;
    sphereGeometry: any;
    meshStandardMaterial: any;
    group: any;
  }
}
