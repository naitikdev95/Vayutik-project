export type UserRole = 'user' | 'admin';
export type ProductCategory = 'App' | 'Software' | 'Website' | 'SaaS' | 'Web App';

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  role: UserRole;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  description: string;
  short_description: string;
  images: string[];
  external_url: string | null;
  average_rating: number;
  review_count: number;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: string;
  product_id: string;
  user_id: string;
  rating: number;
  comment: string;
  created_at: string;
  updated_at: string;
  user?: {
    full_name: string | null;
  };
}

export interface SavedProduct {
  id: string;
  user_id: string;
  product_id: string;
  created_at: string;
  product?: Product;
}
