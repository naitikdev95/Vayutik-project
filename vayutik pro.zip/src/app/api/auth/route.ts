import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

// Simple JWT implementation (no external dependency needed)
function createToken(payload: Record<string, unknown>): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const secret = process.env.JWT_SECRET || 'vaultify-super-secret-key-2024';
  const signature = crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

function verifyToken(token: string): Record<string, unknown> | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const secret = process.env.JWT_SECRET || 'vaultify-super-secret-key-2024';
    const signature = crypto.createHmac('sha256', secret).update(`${parts[0]}.${parts[1]}`).digest('base64url');
    if (signature !== parts[2]) return null;
    return JSON.parse(Buffer.from(parts[1], 'base64url').toString());
  } catch {
    return null;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'signup') {
      const { email, name, password } = body;

      if (!email || !name || !password) {
        return NextResponse.json({ error: 'Email, name, and password are required' }, { status: 400 });
      }

      const existingUser = await db.user.findUnique({ where: { email } });
      if (existingUser) {
        return NextResponse.json({ error: 'Email already exists' }, { status: 409 });
      }

      const hashedPassword = await bcrypt.hash(password, 12);
      const user = await db.user.create({
        data: { email, name, password: hashedPassword },
      });

      const token = createToken({ userId: user.id, email: user.email });

      return NextResponse.json({
        user: { id: user.id, email: user.email, name: user.name, avatar: user.avatar, role: user.role },
        token,
      });
    }

    if (action === 'login') {
      const { email, password } = body;

      if (!email || !password) {
        return NextResponse.json({ error: 'Email and password are required' }, { status: 400 });
      }

      const user = await db.user.findUnique({ where: { email } });
      if (!user) {
        return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
      }

      const valid = await bcrypt.compare(password, user.password);
      if (!valid) {
        return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
      }

      const token = createToken({ userId: user.id, email: user.email });

      return NextResponse.json({
        user: { id: user.id, email: user.email, name: user.name, avatar: user.avatar, role: user.role },
        token,
      });
    }

    if (action === 'verify') {
      const { token } = body;
      if (!token) {
        return NextResponse.json({ error: 'Token is required' }, { status: 400 });
      }

      const payload = verifyToken(token);
      if (!payload) {
        return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
      }

      const user = await db.user.findUnique({
        where: { id: payload.userId as string },
      });

      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }

      return NextResponse.json({
        user: { id: user.id, email: user.email, name: user.name, avatar: user.avatar, role: user.role },
        token,
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
