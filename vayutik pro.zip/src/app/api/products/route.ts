import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const featured = searchParams.get('featured');
    const sort = searchParams.get('sort') || 'rating';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    if (slug) {
      const product = await db.product.findUnique({
        where: { slug },
        include: {
          category: true,
          reviews: {
            include: { user: { select: { id: true, name: true, avatar: true } } },
            orderBy: { createdAt: 'desc' },
          },
          _count: { select: { savedBy: true } },
        },
      });

      if (!product) {
        return NextResponse.json({ error: 'Product not found' }, { status: 404 });
      }

      return NextResponse.json(product);
    }

    // Build where clause
    const where: Record<string, unknown> = {};
    if (category) where.categorySlug = category;
    if (featured === 'true') where.featured = true;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { tagline: { contains: search } },
        { description: { contains: search } },
        { tags: { contains: search } },
      ];
    }

    // Sort
    const orderBy: Record<string, string> = {};
    if (sort === 'rating') orderBy.rating = 'desc';
    else if (sort === 'installs') orderBy.installs = 'desc';
    else if (sort === 'newest') orderBy.createdAt = 'desc';
    else if (sort === 'name') orderBy.name = 'asc';
    else orderBy.rating = 'desc';

    const skip = (page - 1) * limit;

    const [products, total] = await Promise.all([
      db.product.findMany({
        where,
        orderBy,
        skip,
        take: limit,
        include: {
          category: true,
          _count: { select: { reviews: true, savedBy: true } },
        },
      }),
      db.product.count({ where }),
    ]);

    return NextResponse.json({ products, total, page, limit, totalPages: Math.ceil(total / limit) });
  } catch (error) {
    console.error('Products GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
