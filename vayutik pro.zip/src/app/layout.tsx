import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Vaultify — Discover the World's Best Apps & Software",
  description: "Vaultify is the premium platform to discover, review, and install the world's best applications, SaaS products, and developer tools. Curated by the community.",
  keywords: ["Vaultify", "app store", "software marketplace", "SaaS", "web apps", "developer tools", "design tools", "AI tools"],
  authors: [{ name: "Vaultify Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Vaultify — Discover the World's Best Apps & Software",
    description: "The premium platform to discover, review, and install the world's best applications, SaaS products, and developer tools.",
    siteName: "Vaultify",
    type: "website",
  },
};

// Inline script to prevent theme flash — runs before React hydrates
const themeScript = `
(function(){
  try {
    var t = localStorage.getItem('vaultify-theme');
    if (t === 'light' || t === 'dark') {
      document.documentElement.classList.add(t);
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  } catch(e) {
    document.documentElement.classList.add('dark');
  }
})();
`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
          storageKey="vaultify-theme"
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
