'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from 'next-themes';
import { useAuthStore } from '@/store/auth';
import type { Product, Category, Review } from '@/lib/types';
import { formatNumber, formatPricing, getTimeAgo } from '@/lib/types';

// ─── VIEW TYPES ──────────────────────────────────────────────
type View = 'home' | 'browse' | 'product' | 'dashboard';

// ─── ICON COMPONENTS ─────────────────────────────────────────
const IconSearch = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
);
const IconStar = ({ filled, className = '' }: { filled: boolean; className?: string }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
);
const IconDownload = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
);
const IconBookmark = ({ filled }: { filled: boolean }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
);
const IconArrowLeft = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
);
const IconExternalLink = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
);
const IconShield = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);
const IconGrid = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
);
const IconUser = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);
const IconHeart = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
);
const IconLogOut = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
);
const IconChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
);
const IconFilter = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
);
const IconX = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
);
const IconTrending = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
);
const IconSparkles = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.2L22 12l-7.6 2.8L12 22l-2.4-7.2L2 12l7.6-2.8z"/></svg>
);

// ─── STAR RATING COMPONENT ───────────────────────────────────
function StarRating({ rating, size = 'sm', interactive = false, onChange }: { rating: number; size?: 'sm' | 'md' | 'lg'; interactive?: boolean; onChange?: (r: number) => void }) {
  const [hover, setHover] = useState(0);
  const sizeClass = size === 'lg' ? 'text-2xl gap-1' : size === 'md' ? 'text-lg gap-0.5' : 'text-sm gap-0';

  return (
    <div className={`flex items-center ${sizeClass}`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          className={`${interactive ? 'cursor-pointer hover:scale-125 transition-transform' : 'cursor-default'} ${i <= (hover || rating) ? 'text-amber-400' : 'text-muted-foreground/30'}`}
          onClick={() => interactive && onChange?.(i)}
          onMouseEnter={() => interactive && setHover(i)}
          onMouseLeave={() => interactive && setHover(0)}
          aria-label={`${i} star${i > 1 ? 's' : ''}`}
        >
          <IconStar filled={i <= (hover || rating)} />
        </button>
      ))}
    </div>
  );
}

// ─── LOADING SKELETON ────────────────────────────────────────
function ProductSkeleton() {
  return (
    <div className="rounded-2xl border bg-card p-6 animate-shimmer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-muted" />
        <div className="flex-1">
          <div className="h-4 bg-muted rounded w-2/3 mb-2" />
          <div className="h-3 bg-muted rounded w-1/2" />
        </div>
      </div>
      <div className="h-3 bg-muted rounded w-full mb-2" />
      <div className="h-3 bg-muted rounded w-4/5 mb-4" />
      <div className="flex gap-2">
        <div className="h-6 bg-muted rounded-full w-16" />
        <div className="h-6 bg-muted rounded-full w-20" />
      </div>
    </div>
  );
}

// ─── PRODUCT CARD ────────────────────────────────────────────
function ProductCard({ product, onClick, isSaved, onToggleSave }: {
  product: Product;
  onClick: () => void;
  isSaved: boolean;
  onToggleSave: () => void;
}) {
  const [imageError, setImageError] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="card-3d group relative rounded-2xl border bg-card p-4 sm:p-6 cursor-pointer hover:border-primary/30 transition-colors"
      onClick={onClick}
    >
      {/* Save button */}
      <button
        onClick={(e) => { e.stopPropagation(); onToggleSave(); }}
        className="absolute top-3 right-3 z-10 p-1.5 sm:p-2 rounded-full bg-background/80 backdrop-blur-sm border hover:bg-accent transition-colors"
        aria-label={isSaved ? 'Remove from saved' : 'Save product'}
      >
        <span className={isSaved ? 'text-primary' : 'text-muted-foreground'}>
          <IconBookmark filled={isSaved} />
        </span>
      </button>

      {/* Icon & Info */}
      <div className="flex items-start gap-3 sm:gap-4 mb-3 sm:mb-4">
        <div className="relative w-11 h-11 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-xl sm:text-2xl shrink-0 shadow-sm">
          {product.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 sm:gap-2 mb-0.5">
            <h3 className="font-semibold text-sm sm:text-base truncate">{product.name}</h3>
            {product.verified && (
              <span className="text-emerald-500 shrink-0" title="Verified">
                <IconShield />
              </span>
            )}
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm truncate">{product.tagline}</p>
        </div>
      </div>

      {/* Cover Image */}
      {!imageError && product.coverImage && (
        <div className="relative rounded-lg sm:rounded-xl overflow-hidden mb-3 sm:mb-4 aspect-[16/9] bg-muted">
          <img
            src={product.coverImage}
            alt={`${product.name} screenshot`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={() => setImageError(true)}
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      )}

      {/* Description */}
      <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 mb-3 sm:mb-4">{product.description}</p>

      {/* Footer */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <div className="flex items-center gap-1 shrink-0">
            <StarRating rating={product.rating} />
            <span className="text-xs text-muted-foreground ml-0.5 sm:ml-1 font-medium">{product.rating}</span>
          </div>
          <span className="text-xs text-muted-foreground truncate">
            {formatNumber(product.reviewCount)} reviews
          </span>
        </div>
        <span className={`text-[10px] sm:text-xs font-medium px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full shrink-0 ${
          product.pricing === 'free' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
          product.pricing === 'freemium' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' :
          'bg-primary/10 text-primary'
        }`}>
          {formatPricing(product.pricing)}
        </span>
      </div>
    </motion.div>
  );
}

// ─── CATEGORY BADGE ──────────────────────────────────────────
function CategoryBadge({ category, active, onClick }: { category: Category; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap shrink-0 ${
        active
          ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
          : 'bg-secondary/80 text-muted-foreground hover:bg-secondary hover:text-foreground'
      }`}
    >
      <span>{category.icon}</span>
      <span>{category.name}</span>
    </button>
  );
}

// ─── AUTH MODAL ──────────────────────────────────────────────
function AuthModal({ mode, onClose, onSwitch }: { mode: 'login' | 'signup'; onClose: () => void; onSwitch: (m: 'login' | 'signup') => void }) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { setAuth, setLoading: setAuthLoading } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setAuthLoading(true);

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: mode === 'signup' ? 'signup' : 'login',
          email,
          name: mode === 'signup' ? name : undefined,
          password,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Something went wrong');
        setLoading(false);
        setAuthLoading(false);
        return;
      }

      setAuth(data.user, data.token);
      onClose();
    } catch {
      setError('Network error. Please try again.');
      setLoading(false);
      setAuthLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="w-full max-w-md rounded-3xl border bg-card p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{mode === 'login' ? 'Welcome back' : 'Create account'}</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-accent transition-colors" aria-label="Close">
            <IconX />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-destructive/10 text-destructive text-sm">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-sm font-medium mb-1.5">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                placeholder="John Doe"
                required
              />
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              placeholder="you@example.com"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              placeholder="••••••••"
              minLength={6}
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => onSwitch(mode === 'login' ? 'signup' : 'login')}
            className="text-primary font-semibold hover:underline"
          >
            {mode === 'login' ? 'Sign up' : 'Sign in'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── PRODUCT DETAIL VIEW ─────────────────────────────────────
function ProductDetail({ product, onBack, isSaved, onToggleSave, userReview, onAddReview }: {
  product: Product & { reviews: Review[] };
  onBack: () => void;
  isSaved: boolean;
  onToggleSave: () => void;
  userReview: Review | null;
  onAddReview: (data: { rating: number; title: string; comment: string }) => void;
}) {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [imageError, setImageError] = useState(false);
  const { user } = useAuthStore();

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    onAddReview({ rating: reviewRating, title: reviewTitle, comment: reviewComment });
    setShowReviewForm(false);
    setReviewTitle('');
    setReviewComment('');
    setReviewRating(5);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -30 }}
      className="min-h-screen"
    >
      {/* Header */}
      <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-4">
          <button onClick={onBack} className="p-2 rounded-full hover:bg-accent transition-colors" aria-label="Go back">
            <IconArrowLeft />
          </button>
          <h1 className="font-semibold text-lg truncate">{product.name}</h1>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Top Section */}
        <div className="grid lg:grid-cols-5 gap-8 mb-12">
          {/* Main Info */}
          <div className="lg:col-span-3">
            {!imageError && product.coverImage && (
              <div className="relative rounded-2xl overflow-hidden mb-8 aspect-[16/9] bg-muted shadow-xl">
                <img
                  src={product.coverImage}
                  alt={`${product.name} screenshot`}
                  className="w-full h-full object-cover"
                  onError={() => setImageError(true)}
                />
              </div>
            )}

            <div className="flex items-start gap-4 mb-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-4xl shadow-sm shrink-0">
                {product.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 flex-wrap">
                  <h2 className="text-3xl font-bold">{product.name}</h2>
                  {product.verified && (
                    <span className="flex items-center gap-1 text-emerald-500 text-sm font-medium">
                      <IconShield /> Verified
                    </span>
                  )}
                </div>
                <p className="text-lg text-muted-foreground mt-1">{product.tagline}</p>
                <div className="flex items-center gap-4 mt-3 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <StarRating rating={product.rating} size="md" />
                    <span className="font-semibold ml-1">{product.rating}</span>
                    <span className="text-muted-foreground text-sm">({formatNumber(product.reviewCount)} reviews)</span>
                  </div>
                  <span className="text-muted-foreground text-sm">•</span>
                  <span className="text-muted-foreground text-sm flex items-center gap-1">
                    <IconDownload /> {formatNumber(product.installs)} installs
                  </span>
                </div>
              </div>
            </div>

            <p className="text-muted-foreground leading-relaxed mb-6">{product.longDescription || product.description}</p>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-6">
              {product.tags.split(',').map((tag) => (
                <span key={tag} className="px-3 py-1 rounded-full bg-secondary text-sm text-muted-foreground">{tag.trim()}</span>
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={onToggleSave}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
                  isSaved
                    ? 'bg-secondary text-foreground hover:bg-secondary/80'
                    : 'bg-primary text-primary-foreground hover:opacity-90 shadow-lg shadow-primary/25'
                }`}
              >
                {isSaved ? (
                  <>
                    <IconBookmark filled /> Saved
                  </>
                ) : (
                  <>
                    <IconDownload /> Install
                  </>
                )}
              </button>
              {product.website && (
                <a
                  href={product.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border hover:bg-accent transition-colors"
                >
                  Visit Website <IconExternalLink />
                </a>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Info Card */}
            <div className="rounded-2xl border bg-card p-6 space-y-4">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Category</span>
                  <span className="text-sm font-medium">{product.category?.icon} {product.category?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Pricing</span>
                  <span className={`text-sm font-medium ${
                    product.pricing === 'free' ? 'text-emerald-500' :
                    product.pricing === 'freemium' ? 'text-amber-500' :
                    'text-primary'
                  }`}>{formatPricing(product.pricing)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Rating</span>
                  <span className="text-sm font-medium flex items-center gap-1">
                    <span className="text-amber-400">★</span> {product.rating}/5
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Installs</span>
                  <span className="text-sm font-medium">{formatNumber(product.installs)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Reviews</span>
                  <span className="text-sm font-medium">{formatNumber(product.reviewCount)}</span>
                </div>
              </div>
            </div>

            {/* Rating Distribution */}
            {product.reviews.length > 0 && (
              <div className="rounded-2xl border bg-card p-6">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Rating Distribution</h3>
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = product.reviews.filter((r) => r.rating === star).length;
                  const pct = Math.round((count / product.reviews.length) * 100);
                  return (
                    <div key={star} className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs w-3 text-muted-foreground">{star}</span>
                      <span className="text-xs text-amber-400">★</span>
                      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full bg-amber-400 transition-all" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground w-8 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Reviews Section */}
        <div className="border-t pt-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Reviews ({product.reviews.length})</h2>
            {user && (
              <button
                onClick={() => setShowReviewForm(!showReviewForm)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all"
              >
                <IconSparkles />
                {userReview ? 'Edit Review' : 'Write Review'}
              </button>
            )}
          </div>

          {!user && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="mb-2">Sign in to write a review</p>
            </div>
          )}

          {showReviewForm && (
            <motion.form
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmitReview}
              className="rounded-2xl border bg-card p-6 mb-8 space-y-4"
            >
              <h3 className="font-semibold">
                {userReview ? 'Update Your Review' : 'Write a Review'}
              </h3>
              <div>
                <label className="block text-sm font-medium mb-2">Rating</label>
                <StarRating rating={reviewRating} size="lg" interactive onChange={setReviewRating} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Title</label>
                <input
                  type="text"
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="Summarize your experience"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Comment</label>
                <textarea
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
                  rows={4}
                  placeholder="Tell others about your experience..."
                  required
                />
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowReviewForm(false)}
                  className="px-4 py-2 rounded-xl border hover:bg-accent transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all"
                >
                  {userReview ? 'Update' : 'Submit'} Review
                </button>
              </div>
            </motion.form>
          )}

          {/* Reviews List */}
          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
            {product.reviews.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>No reviews yet. Be the first to share your experience!</p>
              </div>
            ) : (
              product.reviews.map((review) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="rounded-2xl border bg-card p-6"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                        {review.user.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{review.user.name}</p>
                        <p className="text-xs text-muted-foreground">{getTimeAgo(review.createdAt)}</p>
                      </div>
                    </div>
                    <StarRating rating={review.rating} />
                  </div>
                  {review.title && <h4 className="font-semibold mb-2">{review.title}</h4>}
                  <p className="text-muted-foreground text-sm leading-relaxed">{review.comment}</p>
                  {review.helpful > 0 && (
                    <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
                      <IconHeart /> {review.helpful} found this helpful
                    </div>
                  )}
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── DASHBOARD VIEW ──────────────────────────────────────────
function DashboardView({ onNavigate, onViewProduct }: {
  onNavigate: (view: View) => void;
  onViewProduct: (product: Product) => void;
}) {
  const { user, token, logout } = useAuthStore();
  const [dashboardData, setDashboardData] = useState<{
    savedItems: Product[];
    reviews: (Review & { product: { id: string; name: string; slug: string; icon: string } })[];
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    fetch('/api/dashboard', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        setDashboardData(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [token]);

  if (!user) {
    onNavigate('home');
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Profile Header */}
        <div className="rounded-3xl border bg-card p-8 mb-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-3xl font-bold text-primary-foreground shadow-lg">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">{user.name}</h1>
              <p className="text-muted-foreground">{user.email}</p>
              <p className="text-xs text-muted-foreground mt-1">Member since {new Date(user.createdAt || '').toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
            </div>
            <button
              onClick={() => { logout(); onNavigate('home'); }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border text-sm hover:bg-accent transition-colors text-muted-foreground"
            >
              <IconLogOut /> Sign Out
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Saved Apps', value: dashboardData?.savedItems.length || 0, icon: <IconBookmark filled={false} /> },
            { label: 'Reviews Written', value: dashboardData?.reviews.length || 0, icon: <IconStar filled={false} /> },
            { label: 'Avg Rating Given', value: dashboardData?.reviews.length ? (dashboardData.reviews.reduce((s, r) => s + r.rating, 0) / dashboardData.reviews.length).toFixed(1) : '—', icon: <IconTrending /> },
            { label: 'Member Since', value: new Date(user.createdAt || '').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }), icon: <IconSparkles /> },
          ].map((stat) => (
            <div key={stat.label} className="rounded-2xl border bg-card p-5">
              <div className="flex items-center gap-2 text-muted-foreground mb-2 text-sm">
                {stat.icon} {stat.label}
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Saved Items */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <IconDownload /> Saved Apps
          </h2>
          {loading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => <ProductSkeleton key={i} />)}
            </div>
          ) : dashboardData?.savedItems.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-12 text-center text-muted-foreground">
              <div className="text-4xl mb-3">📦</div>
              <p className="font-medium mb-1">No saved apps yet</p>
              <p className="text-sm">Browse the marketplace and install apps you love!</p>
              <button onClick={() => onNavigate('browse')} className="mt-4 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all">
                Browse Apps
              </button>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {dashboardData?.savedItems.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => onViewProduct(product)}
                  isSaved={true}
                  onToggleSave={() => {}}
                />
              ))}
            </div>
          )}
        </div>

        {/* My Reviews */}
        <div>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <IconStar filled={false} /> My Reviews
          </h2>
          {loading ? (
            <div className="space-y-4">
              {[...Array(2)].map((_, i) => <ProductSkeleton key={i} />)}
            </div>
          ) : dashboardData?.reviews.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-12 text-center text-muted-foreground">
              <div className="text-4xl mb-3">✍️</div>
              <p className="font-medium mb-1">No reviews yet</p>
              <p className="text-sm">Share your experience with apps you have used!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {dashboardData?.reviews.map((review) => (
                <div key={review.id} className="rounded-2xl border bg-card p-5 flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-xl shrink-0">
                    {review.product.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => onViewProduct(review.product as unknown as Product)}
                        className="font-semibold hover:text-primary transition-colors"
                      >
                        {review.product.name}
                      </button>
                      <StarRating rating={review.rating} />
                    </div>
                    {review.title && <p className="font-medium text-sm mt-1">{review.title}</p>}
                    <p className="text-muted-foreground text-sm mt-1 line-clamp-2">{review.comment}</p>
                    <p className="text-xs text-muted-foreground mt-2">{getTimeAgo(review.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── NAVBAR ──────────────────────────────────────────────────
function Navbar({
  view,
  onNavigate,
  searchQuery,
  setSearchQuery,
  onSearch,
}: {
  view: View;
  onNavigate: (v: View) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSearch: () => void;
}) {
  const { user, isLoading } = useAuthStore();
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [showAuth, setShowAuth] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/25 group-hover:shadow-primary/40 transition-shadow">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
              </div>
              <span className="text-xl font-bold tracking-tight hidden sm:block">
                Vault<span className="text-gradient">ify</span>
              </span>
            </button>

            {/* Nav Links (desktop) */}
            <nav className="hidden md:flex items-center gap-1">
              <button
                onClick={() => onNavigate('home')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  view === 'home' ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => onNavigate('browse')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  view === 'browse' ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                }`}
              >
                Browse
              </button>
              {user && (
                <button
                  onClick={() => onNavigate('dashboard')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    view === 'dashboard' ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                  }`}
                >
                  Dashboard
                </button>
              )}
            </nav>

            {/* Right Side */}
            <div className="flex items-center gap-2">
              {/* Search (desktop) */}
              <div className="hidden md:flex items-center">
                <form onSubmit={(e) => { e.preventDefault(); onSearch(); }} className="relative">
                  <IconSearch />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search apps..."
                    className="w-64 pl-10 pr-4 py-2 rounded-xl bg-secondary/80 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all border border-transparent focus:border-primary/30"
                  />
                </form>
              </div>

              <ThemeToggle />

              {isLoading ? (
                <div className="w-8 h-8 rounded-full bg-muted animate-pulse" />
              ) : user ? (
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-accent transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-xs font-bold text-primary-foreground">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm font-medium hidden lg:block">{user.name}</span>
                </button>
              ) : (
                <div className="hidden sm:flex items-center gap-2">
                  <button
                    onClick={() => { setAuthMode('login'); setShowAuth(true); }}
                    className="px-4 py-2 rounded-xl text-sm font-medium hover:bg-accent transition-colors"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => { setAuthMode('signup'); setShowAuth(true); }}
                    className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all shadow-sm"
                  >
                    Get Started
                  </button>
                </div>
              )}

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
                aria-label="Toggle menu"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t bg-background"
            >
              <div className="px-4 py-4 space-y-3">
                <form onSubmit={(e) => { e.preventDefault(); onSearch(); setMobileMenuOpen(false); }} className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    <IconSearch />
                  </div>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search apps..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-secondary text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  />
                </form>
                <button onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-accent transition-colors text-sm font-medium">Home</button>
                <button onClick={() => { onNavigate('browse'); setMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-accent transition-colors text-sm font-medium">Browse</button>
                {user && (
                  <button onClick={() => { onNavigate('dashboard'); setMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-accent transition-colors text-sm font-medium">Dashboard</button>
                )}
                {!user && (
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => { setAuthMode('login'); setShowAuth(true); setMobileMenuOpen(false); }}
                      className="flex-1 py-2.5 rounded-xl border text-sm font-medium text-center"
                    >
                      Sign In
                    </button>
                    <button
                      onClick={() => { setAuthMode('signup'); setShowAuth(true); setMobileMenuOpen(false); }}
                      className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold text-center"
                    >
                      Get Started
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <AnimatePresence>
        {showAuth && (
          <AuthModal mode={authMode} onClose={() => setShowAuth(false)} onSwitch={setAuthMode} />
        )}
      </AnimatePresence>
    </>
  );
}

// ─── THEME TOGGLE ────────────────────────────────────────────
function ThemeToggle() {
  const { setTheme, resolvedTheme } = useTheme();

  return (
    <button
      onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
      className="p-2 rounded-xl hover:bg-accent transition-colors relative w-9 h-9 flex items-center justify-center"
      aria-label="Toggle theme"
    >
      <svg className="absolute transition-transform scale-100 dark:scale-0 dark:-rotate-90" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
      <svg className="absolute transition-transform scale-0 dark:scale-100 rotate-90 dark:rotate-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
    </button>
  );
}

// ─── FOOTER ──────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="border-t bg-card/50 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
              </div>
              <span className="text-lg font-bold">Vaultify</span>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">Discover, review, and install the world&apos;s best applications. Curated by the community.</p>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-semibold text-xs sm:text-sm mb-2 sm:mb-3">Product</h3>
            <ul className="space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-muted-foreground">
              <li><button className="hover:text-foreground transition-colors">Browse Apps</button></li>
              <li><button className="hover:text-foreground transition-colors">Categories</button></li>
              <li><button className="hover:text-foreground transition-colors">Top Rated</button></li>
              <li><button className="hover:text-foreground transition-colors">Recently Added</button></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-xs sm:text-sm mb-2 sm:mb-3">Company</h3>
            <ul className="space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-muted-foreground">
              <li><button className="hover:text-foreground transition-colors">About</button></li>
              <li><button className="hover:text-foreground transition-colors">Blog</button></li>
              <li><button className="hover:text-foreground transition-colors">Careers</button></li>
              <li><button className="hover:text-foreground transition-colors">Contact</button></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-xs sm:text-sm mb-2 sm:mb-3">Legal</h3>
            <ul className="space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-muted-foreground">
              <li><button className="hover:text-foreground transition-colors">Privacy Policy</button></li>
              <li><button className="hover:text-foreground transition-colors">Terms of Service</button></li>
              <li><button className="hover:text-foreground transition-colors">Cookie Policy</button></li>
            </ul>
          </div>
        </div>

        <div className="pt-6 sm:pt-8 border-t flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
          <p className="text-xs text-muted-foreground">© 2025 Vaultify. All rights reserved.</p>
          <div className="flex items-center gap-4 text-muted-foreground">
            <button className="hover:text-foreground transition-colors" aria-label="Twitter">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </button>
            <button className="hover:text-foreground transition-colors" aria-label="GitHub">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────
export default function Home() {
  const [view, setView] = useState<View>('home');
  const [products, setProducts] = useState<Product[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('rating');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSearch, setActiveSearch] = useState('');
  const [currentProduct, setCurrentProduct] = useState<(Product & { reviews: Review[] }) | null>(null);
  const [savedSlugs, setSavedSlugs] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [showAuth, setShowAuth] = useState(false);
  const { user, token, setAuth, logout, setLoading: setAuthLoading } = useAuthStore();

  // Fetch initial data
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [productsRes, featuredRes] = await Promise.all([
        fetch('/api/products?limit=50'),
        fetch('/api/products?featured=true&limit=8'),
      ]);
      const productsData = await productsRes.json();
      const featuredData = await featuredRes.json();
      setProducts(productsData.products || []);
      setFeaturedProducts(featuredData.products || []);

      // Fetch categories from products
      const cats: Record<string, Category> = {};
      (productsData.products || []).forEach((p: Product) => {
        if (p.category && !cats[p.category.slug]) {
          cats[p.category.slug] = p.category;
        }
      });
      setCategories(Object.values(cats));
    } catch (e) {
      console.error('Failed to fetch data', e);
    }
    setLoading(false);
  }, []);

  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    void fetchData();
  }, [fetchData]);
  /* eslint-enable react-hooks/set-state-in-effect */

  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (!token) {
      setSavedSlugs(new Set());
      return;
    }
    fetch('/api/saved', { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((data) => {
        setSavedSlugs(new Set((data.savedItems || []).map((s: Product) => s.slug)));
      })
      .catch(() => {});
  }, [token]);
  /* eslint-enable react-hooks/set-state-in-effect */

  // Verify auth on mount
  useEffect(() => {
    const saved = useAuthStore.getState();
    if (saved.token && saved.user) {
      fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', token: saved.token }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.user) setAuth(data.user, data.token);
          else logout();
        })
        .catch(() => logout());
    }
  }, [setAuth, logout]);

  // Toggle save
  const toggleSave = async (productSlug: string, productId: string) => {
    if (!token) {
      setAuthMode('login');
      setShowAuth(true);
      return;
    }
    const isSaved = savedSlugs.has(productSlug);
    try {
      if (isSaved) {
        await fetch(`/api/saved?productId=${productId}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedSlugs((prev) => {
          const next = new Set(prev);
          next.delete(productSlug);
          return next;
        });
      } else {
        await fetch('/api/saved', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ productId }),
        });
        setSavedSlugs((prev) => new Set(prev).add(productSlug));
      }
    } catch (e) {
      console.error('Failed to toggle save', e);
    }
  };

  // Add review
  const addReview = async (productId: string, data: { rating: number; title: string; comment: string }) => {
    if (!token) return;
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ productId, ...data }),
      });
      const review = await res.json();
      if (currentProduct) {
        // Refresh product detail
        const existingIdx = currentProduct.reviews.findIndex((r) => r.userId === user?.id);
        const updatedReviews = [...currentProduct.reviews];
        if (existingIdx >= 0) updatedReviews[existingIdx] = review;
        else updatedReviews.unshift(review);
        setCurrentProduct({ ...currentProduct, reviews: updatedReviews });
      }
    } catch (e) {
      console.error('Failed to add review', e);
    }
  };

  // Handle search
  const handleSearch = () => {
    setActiveSearch(searchQuery);
    setView('browse');
  };

  // Handle product click
  const handleProductClick = async (product: Product) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/products?slug=${product.slug}`);
      const data = await res.json();
      setCurrentProduct(data);
      setView('product');
    } catch (e) {
      console.error('Failed to fetch product', e);
    }
    setLoading(false);
  };

  // Filtered products
  const filteredProducts = products.filter((p) => {
    if (selectedCategory !== 'all' && p.categorySlug !== selectedCategory) return false;
    if (activeSearch) {
      const q = activeSearch.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.tags.toLowerCase().includes(q)
      );
    }
    return true;
  }).sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'installs') return b.installs - a.installs;
    if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return 0;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar
        view={view}
        onNavigate={(v) => {
          setView(v);
          if (v === 'browse' && !activeSearch) setActiveSearch('');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onSearch={handleSearch}
      />

      <div className="flex-1 min-h-0">
        <AnimatePresence mode="wait">
        <main className="h-full">
          {loading && view === 'home' ? (
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => <ProductSkeleton key={i} />)}
              </div>
            </div>
          ) : view === 'home' ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {/* ─── HERO SECTION ─── */}
              <section className="relative overflow-hidden">
                {/* Background */}
                <div className="absolute inset-0 hero-grid" />
                <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
                <div className="absolute top-20 right-0 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none" />

                <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-20 lg:py-36">
                  <div className="text-center max-w-4xl mx-auto">
                    {/* Badge */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="inline-flex items-center gap-2 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mb-6 sm:mb-8 border border-primary/20"
                    >
                      <IconSparkles />
                      <span>Trusted by 500K+ professionals</span>
                    </motion.div>

                    {/* Heading */}
                    <motion.h1
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="text-3xl sm:text-5xl lg:text-7xl font-bold tracking-tight leading-[1.1] mb-4 sm:mb-6"
                    >
                      Discover the World&apos;s
                      <br />
                      <span className="text-gradient">Best Software</span>
                    </motion.h1>

                    {/* Subtitle */}
                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-6 sm:mb-10 leading-relaxed"
                    >
                      Explore thousands of curated apps, SaaS tools, and developer platforms.
                      Read real reviews, compare features, and find your perfect solution.
                    </motion.p>

                    {/* CTA Buttons */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4"
                    >
                      <button
                        onClick={() => setView('browse')}
                        className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-3 sm:py-4 rounded-2xl bg-primary text-primary-foreground font-semibold text-base sm:text-lg hover:opacity-90 transition-all shadow-xl shadow-primary/25 animate-pulse-glow"
                      >
                        Explore Marketplace
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                      </button>
                      {!user && (
                        <button
                          onClick={() => { setAuthMode('signup'); setShowAuth(true); }}
                          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-3 sm:py-4 rounded-2xl border font-semibold text-base sm:text-lg hover:bg-accent transition-colors"
                        >
                          Join for Free
                        </button>
                      )}
                    </motion.div>

                    {/* Stats */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                      className="flex items-center justify-center gap-6 sm:gap-12 mt-10 sm:mt-16"
                    >
                      {[
                        { value: '16K+', label: 'Apps & Tools' },
                        { value: '500K+', label: 'Users' },
                        { value: '4.8★', label: 'Avg Rating' },
                      ].map((stat) => (
                        <div key={stat.label} className="text-center">
                          <div className="text-xl sm:text-3xl font-bold">{stat.value}</div>
                          <div className="text-[10px] sm:text-sm text-muted-foreground mt-0.5 sm:mt-1">{stat.label}</div>
                        </div>
                      ))}
                    </motion.div>
                  </div>
                </div>
              </section>

              {/* ─── FEATURED APPS ─── */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
                <div className="flex items-center justify-between mb-6 sm:mb-8">
                  <div>
                    <h2 className="text-xl sm:text-3xl font-bold mb-1 sm:mb-2">Featured Apps</h2>
                    <p className="text-sm sm:text-base text-muted-foreground">Hand-picked by our editorial team</p>
                  </div>
                  <button
                    onClick={() => setView('browse')}
                    className="hidden sm:flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
                  >
                    View all
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                  </button>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {featuredProducts.slice(0, 8).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onClick={() => handleProductClick(product)}
                      isSaved={savedSlugs.has(product.slug)}
                      onToggleSave={() => toggleSave(product.slug, product.id)}
                    />
                  ))}
                </div>
              </section>

              {/* ─── CATEGORIES ─── */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
                <div className="text-center mb-6 sm:mb-10">
                  <h2 className="text-xl sm:text-3xl font-bold mb-1 sm:mb-2">Browse by Category</h2>
                  <p className="text-sm sm:text-base text-muted-foreground">Find exactly what you need</p>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                  {categories.map((cat) => (
                    <button
                      key={cat.slug}
                      onClick={() => {
                        setSelectedCategory(cat.slug);
                        setActiveSearch('');
                        setView('browse');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="group rounded-xl sm:rounded-2xl border bg-card p-4 sm:p-6 hover:border-primary/30 hover:shadow-lg transition-all duration-300 text-left"
                    >
                      <div className="text-2xl sm:text-3xl mb-2 sm:mb-3">{cat.icon}</div>
                      <h3 className="font-semibold text-sm sm:text-base mb-0.5 sm:mb-1 group-hover:text-primary transition-colors">{cat.name}</h3>
                      <p className="text-xs sm:text-sm text-muted-foreground">
                        {products.filter((p) => p.categorySlug === cat.slug).length} apps
                      </p>
                    </button>
                  ))}
                </div>
              </section>

              {/* ─── TOP RATED ─── */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
                <div className="flex items-center justify-between mb-6 sm:mb-8">
                  <div>
                    <h2 className="text-xl sm:text-3xl font-bold mb-1 sm:mb-2">Top Rated</h2>
                    <p className="text-sm sm:text-base text-muted-foreground">Highest rated by the community</p>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[...products].sort((a, b) => b.rating - a.rating).slice(0, 6).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onClick={() => handleProductClick(product)}
                      isSaved={savedSlugs.has(product.slug)}
                      onToggleSave={() => toggleSave(product.slug, product.id)}
                    />
                  ))}
                </div>
              </section>

              {/* ─── CTA BANNER ─── */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
                <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden border bg-gradient-to-br from-primary/10 via-primary/5 to-emerald-500/5 p-6 sm:p-16 text-center">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-emerald-500/5 pointer-events-none" />
                  <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
                  <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
                  <div className="relative">
                    <h2 className="text-2xl sm:text-4xl font-bold mb-3 sm:mb-4">Ready to find your next favorite app?</h2>
                    <p className="text-muted-foreground text-sm sm:text-lg max-w-2xl mx-auto mb-6 sm:mb-8">
                      Join thousands of professionals who discover and review the best software on Vaultify.
                    </p>
                    <button
                      onClick={() => setView('browse')}
                      className="inline-flex items-center justify-center gap-2 w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 rounded-2xl bg-primary text-primary-foreground font-semibold text-base sm:text-lg hover:opacity-90 transition-all shadow-xl shadow-primary/25"
                    >
                      Get Started Free
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </button>
                  </div>
                </div>
              </section>
            </motion.div>
          ) : view === 'browse' ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
              {/* Browse Header */}
              <div className="mb-6 sm:mb-8">
                <h1 className="text-2xl sm:text-4xl font-bold mb-1 sm:mb-2">
                  {activeSearch ? `Results for "${activeSearch}"` : 'Browse Apps'}
                </h1>
                <p className="text-muted-foreground">
                  {activeSearch
                    ? `${filteredProducts.length} apps found`
                    : `${filteredProducts.length} apps available`}
                </p>
              </div>

              {/* Categories */}
              <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
                <CategoryBadge
                  category={{ id: 'all', name: 'All', slug: 'all', icon: '🌐', color: '' }}
                  active={selectedCategory === 'all'}
                  onClick={() => setSelectedCategory('all')}
                />
                {categories.map((cat) => (
                  <CategoryBadge
                    key={cat.slug}
                    category={cat}
                    active={selectedCategory === cat.slug}
                    onClick={() => setSelectedCategory(cat.slug)}
                  />
                ))}
              </div>

              {/* Sort */}
              <div className="flex items-center gap-2 sm:gap-3 mb-6 overflow-x-auto pb-2">
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-muted-foreground shrink-0">
                  <IconFilter />
                  <span className="hidden sm:inline">Sort by:</span>
                </div>
                {[
                  { value: 'rating', label: 'Top Rated' },
                  { value: 'installs', label: 'Most Installed' },
                  { value: 'newest', label: 'Newest' },
                  { value: 'name', label: 'Name' },
                ].map((sort) => (
                  <button
                    key={sort.value}
                    onClick={() => setSortBy(sort.value)}
                    className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                      sortBy === sort.value
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {sort.label}
                  </button>
                ))}
              </div>

              {/* Products Grid */}
              {filteredProducts.length === 0 ? (
                <div className="text-center py-16 sm:py-20">
                  <div className="text-4xl sm:text-5xl mb-4">🔍</div>
                  <h3 className="text-lg sm:text-xl font-semibold mb-2">No apps found</h3>
                  <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
                  <button
                    onClick={() => { setSelectedCategory('all'); setActiveSearch(''); setSearchQuery(''); }}
                    className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all"
                  >
                    Clear Filters
                  </button>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onClick={() => handleProductClick(product)}
                      isSaved={savedSlugs.has(product.slug)}
                      onToggleSave={() => toggleSave(product.slug, product.id)}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          ) : view === 'product' && currentProduct ? (
            <ProductDetail
              product={currentProduct}
              onBack={() => setView('browse')}
              isSaved={savedSlugs.has(currentProduct.slug)}
              onToggleSave={() => toggleSave(currentProduct.slug, currentProduct.id)}
              userReview={user ? currentProduct.reviews.find((r) => r.userId === user.id) || null : null}
              onAddReview={(data) => addReview(currentProduct.id, data)}
            />
          ) : view === 'dashboard' ? (
            <DashboardView onNavigate={setView} onViewProduct={(p) => handleProductClick(p)} />
          ) : null}
        </main>
      </AnimatePresence>
      </div>

      <AnimatePresence>
        {showAuth && (
          <AuthModal mode={authMode} onClose={() => setShowAuth(false)} onSwitch={setAuthMode} />
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}
