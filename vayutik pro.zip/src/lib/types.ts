export interface Product {
  id: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  longDescription: string;
  icon: string;
  coverImage: string;
  website: string;
  pricing: string;
  categorySlug: string;
  tags: string;
  rating: number;
  reviewCount: number;
  installs: number;
  featured: boolean;
  verified: boolean;
  createdAt: string;
  updatedAt: string;
  category?: Category;
  _count?: { reviews: number; savedBy: number };
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
}

export interface Review {
  id: string;
  userId: string;
  productId: string;
  rating: number;
  title: string;
  comment: string;
  helpful: number;
  createdAt: string;
  updatedAt: string;
  user: { id: string; name: string; avatar: string };
}

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  success: boolean;
}

export function formatNumber(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
}

export function formatPricing(pricing: string): string {
  const map: Record<string, string> = {
    free: 'Free',
    freemium: 'Freemium',
    subscription: 'Paid',
    'pay-once': 'One-time',
    open: 'Open Source',
  };
  return map[pricing] || pricing;
}

export function getTimeAgo(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}
